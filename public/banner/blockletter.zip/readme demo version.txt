OTF and TTF: Blockletter (Regular, Outlines, 3D, and Tall)
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Who's up for a movie night? In a distant land far, far away VHS tapes were once king. Blockletter is a clean, basic sans serif based on the now defunct Blockbuster Video logo. It also resembles the Hollywood sign, military lettering, and type found on collegiate apparel. This is a complete overhaul 
based on a font I designed years ago. Blockletter features only uppercase characters and basic punctuation but contains European accents, diacritics, and kerning. The regular version is included for personal use. The other 3 are available with purchase of a commercial license. If you don't require 
a license but still want the others you can buy the full version for $15. Send payment via PayPal (dennis@sharkshock.net) and let me know.

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for 
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 


visit www.sharkshock.net for more and take a bite out of BORING design!

tags: sans, sans serif, magazine, display, font, typeface, sports, illustration, straight, geo, san, publishing, logo, company, Sharkshock, Europe, diacritics, Polish, Czech, German, French, accents, Spanish, Latin, kerning, Blockbuster, square, block, blocky


